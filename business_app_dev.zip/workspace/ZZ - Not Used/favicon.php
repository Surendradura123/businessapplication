<!DOCTYPE html>

<!-- This page is used to set the favicon on the site. It's a PHP file even though it does not contain PHP so it can be easily be included on other pages. -->
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="img/fav_icon.ico">

</head>
<body>
     <base href="/">
</body>
</html>